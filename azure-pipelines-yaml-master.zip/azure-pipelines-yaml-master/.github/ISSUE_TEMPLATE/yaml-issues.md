---
name: Talk about YAML
about: 'We can talk about YAML here. We cannot take problem reports or support requests.'
title: ''
labels: ''
assignees: ''

---

This repo is for working in the open on Azure Pipelines YAML features. It's not a great place to make [new feature requests](https://developercommunity.visualstudio.com/spaces/21/index.html), [report problems](https://developercommunity.visualstudio.com/spaces/21/index.html), or [get support](https://azure.microsoft.com/en-us/support/devops/). Issues you open here may sit unreviewed for a very long time.
